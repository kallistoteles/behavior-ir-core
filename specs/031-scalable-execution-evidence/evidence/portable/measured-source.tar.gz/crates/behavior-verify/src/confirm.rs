//! Confirmation of counterexamples by evaluation (research R7).
//!
//! A solver model is turned into an ordinary evaluation request and run through the engine's own
//! evaluator. A counterexample is reported only if the evaluator reproduces the failure; the
//! decision record becomes part of the finding.

use std::collections::BTreeMap;

use serde_json::{Map, Value as Json, json};

use behavior_core::semantic::module::Module;
use behavior_core::semantic::types::Type;
use behavior_core::semantic::value::encode;

use crate::encode::{Encoder, FactKind, Term, model_value};
use crate::smt::SmtValue;

/// What the evaluator must show for the counterexample to count.
#[derive(Debug, Clone)]
pub enum Expect {
    /// The actual first failed child constraint is this synthesized Ref site.
    ReferenceFails {
        declaration: String,
        field: String,
        hash: String,
    },
    /// The `index`-th trace step of `phase` evaluates to `false` and the result is DENY.
    RuleFails {
        phase: &'static str,
        index: usize,
    },
    /// The result is ERROR with exactly this message (`"<error> in <expression>"`).
    Error {
        message: String,
    },
    SemanticError {
        code: String,
        node: String,
    },
    /// The result is DENY with this first reason code (feature 006: `DANGLING_REFERENCE`).
    Reason {
        code: &'static str,
    },
}

/// A confirmed counterexample: the request sections and the decision record.
#[derive(Debug, Clone)]
pub struct Confirmed {
    pub state: Json,
    pub input: Json,
    pub context: Json,
    /// The evaluation facts of the counterexample (feature 006), if it needs any.
    pub facts: Option<Json>,
    pub record: Json,
}

/// The entity an identity type refers to.
fn id_entity(t: &Type) -> Option<&str> {
    match t {
        Type::Id(e) => Some(e),
        Type::Option(inner) => id_entity(inner),
        _ => None,
    }
}

/// Builds the request sections from a model: option flags become `null`, identities are renamed
/// `e0`, `e1`, … in order of first appearance (preserving equality between identities of the
/// same entity type), decimals must be exactly representable. The action encoder refuses
/// child schedules that require an unsupported ordering of same-type decoded identities;
/// renaming must not be used to claim that arbitrary SMT string order is canonical order.
pub fn request_sections(
    enc: &Encoder<'_>,
    model: &BTreeMap<String, SmtValue>,
) -> Option<[Json; 3]> {
    request_parts(enc, model).map(|(s, _)| s)
}

type Ids = BTreeMap<(String, String), String>;

fn renamed(ids: &mut Ids, entity: &str, raw: &str) -> String {
    let next = format!("e{}", ids.len());
    ids.entry((entity.to_string(), raw.to_string()))
        .or_insert(next)
        .clone()
}

/// The request sections and the facts section (feature 006) of a model. A `refd_T(x)` fact
/// becomes an incoming reference from an invented entity not bound by the action (`x0`, `x1`, …,
/// never an `e…` identity), plus the bound entities whose reference fields point at `x`.
pub fn request_parts(
    enc: &Encoder<'_>,
    model: &BTreeMap<String, SmtValue>,
) -> Option<([Json; 3], Option<Json>)> {
    let mut ids: Ids = BTreeMap::new();
    let sections = sections_with(enc, model, &mut ids)?;
    let mut facts = behavior_core::Facts::default();
    let mut invented = 0usize;
    for f in &enc.facts {
        let SmtValue::Str(raw) = model.get(&f.id)? else {
            return None;
        };
        let SmtValue::Bool(v) = model.get(&f.value)? else {
            return None;
        };
        let id = renamed(&mut ids, &f.entity, raw);
        let key = (f.entity.clone(), id.clone());
        match f.kind {
            FactKind::Exists => {
                facts.existence.insert(key, *v);
            }
            FactKind::Used => {
                facts.identities.insert(key, *v);
            }
            FactKind::Refd => {
                if enc.reference_world {
                    // The private residual fact is reconstructed below from
                    // the complete known/slot parent, not an invented edge.
                    continue;
                }
                if facts.references.contains_key(&key) {
                    continue;
                }
                let mut edges = Vec::new();
                if *v {
                    let (entity, field) = enc.module.references_to(&f.entity).into_iter().next()?;
                    edges.push(behavior_core::RefEdge {
                        entity,
                        id: format!("x{invented}"),
                        field,
                    });
                    invented += 1;
                }
                for (param, source) in &enc.world.bound {
                    let Some(item) = enc.module.entity(source) else {
                        continue;
                    };
                    for (field, target) in item.reference_fields() {
                        if target == f.entity
                            && sections[0][param.as_str()][field] == Json::String(id.clone())
                        {
                            let bid = sections[0][param.as_str()]["id"].as_str()?.to_string();
                            edges.push(behavior_core::RefEdge {
                                entity: source.clone(),
                                id: bid,
                                field: field.to_string(),
                            });
                        }
                    }
                }
                edges.sort();
                facts.references.insert(key, edges);
            }
        }
    }
    // Feature 007: every queried type is given as a universe (the named members of the witness:
    // bound entities and present slots), which also answers existence of that type.
    for (entity, slots) in &enc.slots {
        facts.existence.retain(|(e, _), _| e != entity);
        let mut members = BTreeMap::new();
        for (param, source) in &enc.world.bound {
            if source == entity
                && let Some(v) = sections[0].get(param.as_str())
                && let Some(id) = v["id"].as_str()
            {
                members.insert(id.to_string(), v.clone());
            }
        }
        for slot in slots {
            if model.get(&slot.present)? != &SmtValue::Bool(true) {
                continue;
            }
            let crate::encode::Binding::Entity { fields, .. } = &slot.binding else {
                return None;
            };
            let item = enc.module.entity(entity)?;
            let mut value = Map::new();
            for (f, term) in fields {
                let ty = item.field_type(f)?;
                value.insert(f.clone(), term_json(model, &mut ids, ty, term)?);
            }
            let id = value.get("id")?.as_str()?.to_string();
            members.insert(id, Json::Object(value));
        }
        facts.universe.insert(entity.clone(), members);
    }
    // Fresh confirmation uses complete-parent validation for every admitted
    // language profile. Empty types are evidence too, not unknown membership.
    // Do not invent a row/value merely to satisfy a free existence or reference
    // fact: a contradictory or invalid finite parent must fail confirmation.
    for entity in enc.module.entities().keys() {
        let members = facts.universe.entry(entity.clone()).or_default();
        for (parameter, source) in &enc.world.bound {
            if source == entity
                && let Some(value) = sections[0].get(parameter)
                && let Some(id) = value["id"].as_str()
            {
                members.insert(id.into(), value.clone());
            }
        }
    }
    if enc.reference_world {
        // The complete finite snapshot is the authority for existence. SMT
        // also names fields of absent witness slots; free facts for those
        // unused values must not contradict the reconstructed universe.
        // Core rechecks the complete parent and the exact selected failure.
        facts.existence.clear();
        for fact in &enc.facts {
            if fact.kind != FactKind::Refd {
                continue;
            }
            let SmtValue::Str(raw) = model.get(&fact.id)? else {
                return None;
            };
            let target = renamed(&mut ids, &fact.entity, raw);
            let mut edges = Vec::new();
            for (source, rows) in &facts.universe {
                let item = enc.module.entity(source)?;
                for (id, row) in rows {
                    for (field, ty) in item.reference_fields() {
                        if ty == fact.entity
                            && row.get(field) == Some(&Json::String(target.clone()))
                        {
                            edges.push(behavior_core::RefEdge {
                                entity: source.clone(),
                                id: id.clone(),
                                field: field.into(),
                            });
                        }
                    }
                }
            }
            edges.sort();
            facts
                .references
                .insert((fact.entity.clone(), target), edges);
        }
    }
    let facts = (!facts.is_empty()).then(|| facts.to_json());
    Some((sections, facts))
}

/// The request value of a model term of type `ty` (identities renamed, options `null`).
fn term_json(
    model: &BTreeMap<String, SmtValue>,
    ids: &mut Ids,
    ty: &Type,
    term: &Term,
) -> Option<Json> {
    let (present, val) = match term {
        Term::Plain(t) => (true, model.get(t)?),
        Term::Opt { some, val } => (model.get(some)? == &SmtValue::Bool(true), model.get(val)?),
    };
    Some(if !present {
        Json::Null
    } else if let Some(entity) = id_entity(ty) {
        let SmtValue::Str(raw) = val else { return None };
        json!(renamed(ids, entity, raw))
    } else {
        encode(ty, &model_value(ty, val)?)
    })
}

fn sections_with(
    enc: &Encoder<'_>,
    model: &BTreeMap<String, SmtValue>,
    ids: &mut Ids,
) -> Option<[Json; 3]> {
    let mut sections: [Map<String, Json>; 3] = Default::default();
    for var in &enc.inputs {
        let (present, val) = match &var.term {
            Term::Plain(t) => (true, model.get(t)?),
            Term::Opt { some, val } => (model.get(some)? == &SmtValue::Bool(true), model.get(val)?),
        };
        let json = if !present {
            Json::Null
        } else if let Some(entity) = id_entity(&var.ty) {
            let SmtValue::Str(raw) = val else { return None };
            json!(renamed(ids, entity, raw))
        } else {
            encode(&var.ty, &model_value(&var.ty, val)?)
        };
        let idx = match var.section {
            "state" => 0,
            "input" => 1,
            _ => 2,
        };
        match &var.field {
            Some(f) => {
                let entry = sections[idx]
                    .entry(var.param.clone())
                    .or_insert_with(|| json!({}));
                if let Json::Object(m) = entry {
                    m.insert(f.clone(), json);
                }
            }
            None => {
                sections[idx].insert(var.param.clone(), json);
            }
        }
    }
    let [s, i, c] = sections;
    Some([Json::Object(s), Json::Object(i), Json::Object(c)])
}

fn reproduces(record: &Json, expect: &Expect) -> bool {
    match expect {
        Expect::ReferenceFails {
            declaration,
            field,
            hash,
        } => {
            record["result"] == "DENY"
                && record["reasons"][0]["code"] == "CONSTRAINT_VIOLATED"
                && record["trace"]
                    .as_array()
                    .and_then(|steps| steps.iter().find(|s| s["outcome"] == Json::Bool(false)))
                    .is_some_and(|s| {
                        s["phase"] == "constraint_post"
                            && s["obligation"]["source"] == "synthesized_reference"
                            && s["obligation"]["entity_declaration"] == *declaration
                            && s["obligation"]["field"] == *field
                            && s["obligation"]["hash"] == *hash
                    })
        }
        Expect::RuleFails { phase, index } => {
            record["result"] == "DENY"
                && record["trace"]
                    .as_array()
                    .and_then(|t| t.iter().filter(|s| s["phase"] == *phase).nth(*index))
                    .is_some_and(|s| s["outcome"] == Json::Bool(false))
        }
        Expect::Error { message } => {
            record["result"] == "ERROR" && record["reasons"][0]["message"] == message.as_str()
        }
        Expect::SemanticError { code, node } => {
            record["result"] == "ERROR"
                && record["reasons"][0]["details"]["code"] == *code
                && record["reasons"][0]["details"]["node"] == *node
        }
        Expect::Reason { code } => {
            record["result"] == "DENY" && record["reasons"][0]["code"] == *code
        }
    }
}

/// Evaluates the model as a request; `Some` only if the expected failure is reproduced.
pub fn confirm(
    module: &Module,
    enc: &Encoder<'_>,
    action: &str,
    model: &BTreeMap<String, SmtValue>,
    expect: &Expect,
) -> Option<Confirmed> {
    let ([state, input, context], facts) = request_parts(enc, model)?;
    let mut request = json!({
        "action": action,
        "data_version": "verification",
        "state": state,
        "input": input,
        "context": context,
    });
    if let (Some(f), Json::Object(m)) = (&facts, &mut request) {
        m.insert("facts".into(), f.clone());
    }
    let record = behavior_core::evaluate(module, &request.to_string());
    let record = record.as_json().clone();
    if !reproduces(&record, expect) {
        return None;
    }
    // Feature 007: a counterexample confirmed on a universe is reported with the facts its
    // evaluation observed (query and field facts), if those reproduce it on their own.
    let mut facts = facts;
    if !enc.slots.is_empty()
        && let Some(observed) = record.get("facts")
    {
        request["facts"] = observed.clone();
        let again = behavior_core::evaluate(module, &request.to_string());
        if again.as_json() == &record {
            facts = Some(observed.clone());
        }
    }
    Some(Confirmed {
        state,
        input,
        context,
        facts,
        record,
    })
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod reference_tests {
    use super::*;
    #[test]
    fn actual_first_reference_failure_requires_exact_declaration_field_and_hash() {
        let module = behavior_core::admit(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../tests/fixtures/verify/ref-removals/guarded-unguarded.json"
        )))
        .unwrap();
        let old = json!({"id":"old","value":1});
        let h = json!({"id":"h","target":"old"});
        let request = json!({"action":"remove_free","data_version":"confirmation-control","state":{"old":old},"input":{},"context":{},"facts":{"universe":[{"entity":"Target","members":[old]},{"entity":"Holder","members":[h]}]}});
        let record = behavior_core::evaluate(&module, &request.to_string());
        let r = record.as_json();
        let first = r["trace"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["outcome"] == false)
            .unwrap();
        let declaration = first["obligation"]["entity_declaration"]
            .as_str()
            .unwrap()
            .to_string();
        let hash = first["obligation"]["hash"].as_str().unwrap().to_string();
        assert!(reproduces(
            r,
            &Expect::ReferenceFails {
                declaration: declaration.clone(),
                field: "target".into(),
                hash: hash.clone()
            }
        ));
        for expected in [
            Expect::ReferenceFails {
                declaration: declaration.clone(),
                field: "different".into(),
                hash: hash.clone(),
            },
            Expect::ReferenceFails {
                declaration: "different".into(),
                field: "target".into(),
                hash: hash.clone(),
            },
            Expect::ReferenceFails {
                declaration,
                field: "target".into(),
                hash: "different".into(),
            },
        ] {
            assert!(!reproduces(r, &expected));
        }
    }
}
