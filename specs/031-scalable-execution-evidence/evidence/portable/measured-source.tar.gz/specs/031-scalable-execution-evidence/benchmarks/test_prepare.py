import unittest
from pathlib import Path
import prepare
import artifacts as a

class PreparationTests(unittest.TestCase):
    def test_compiled_fixture_is_an_explicit_source_input(self):
        files=prepare.source_inventory()
        for name in ['tests/fixtures/soundness/module.json','tests/fixtures/commands/modules/receipt.json']:
            self.assertTrue(name in files, 'missing explicit compiled fixture input: '+name)
            self.assertEqual(files[name],a.digest((prepare.ROOT/name).read_bytes()))

if __name__=='__main__': unittest.main()
