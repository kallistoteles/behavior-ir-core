#!/usr/bin/env bash
# Determinism gate (constitution: Development Workflow and Quality Gates).
# Runs every deterministic operation twice and compares the outputs byte for byte.
#
#   scripts/determinism-check.sh [--core]
#
# The engine's part: the command line over the conformance fixtures and the store examples. The
# bindings' part (their examples and smoke scenario) runs in the ecosystem repository; `--core`
# is accepted for symmetry with it (feature 011).
set -euo pipefail

cd "$(dirname "$0")/.."
case "${1:-}" in
  "" | --core) ;;
  *) echo "usage: scripts/determinism-check.sh [--core]" >&2; exit 2 ;;
esac
do_core=1
BIN="${BEHAVIOR_BIN:-target/debug/behavior}"
if [ "$do_core" -eq 1 ] && [ ! -x "$BIN" ]; then
  echo "determinism-check: $BIN not found; run 'cargo build --workspace' first" >&2
  exit 1
fi

fail=0
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# The section of the check the outputs belong to (feature 011): `core` here; the ecosystem's
# determinism check records its own section.
section=core

# digest <label> <file>: with BEHAVIOR_DIGEST_DIR set, records the output's SHA-256 under its
# section and label (scripts/conformance-digest.sh), so a move can prove it changed no output.
digest() {
  if [ -n "${BEHAVIOR_DIGEST_DIR:-}" ]; then
    printf '%s\t%s\t%s\n' "$section" "$1" "$(sha256sum <"$2" | cut -d' ' -f1)" \
      >>"$BEHAVIOR_DIGEST_DIR/outputs.tsv"
  fi
}

# run_twice <label> <command...>: exit codes and stdout must match between runs.
run_twice() {
  local label="$1"; shift
  local rc1=0 rc2=0
  "$@" >"$tmp/a" 2>/dev/null || rc1=$?
  "$@" >"$tmp/b" 2>/dev/null || rc2=$?
  if [ "$rc1" -ne "$rc2" ] || ! cmp -s "$tmp/a" "$tmp/b"; then
    echo "NOT DETERMINISTIC: $label" >&2
    fail=1
  fi
  digest "$label" "$tmp/a"
}

if [ "$do_core" -eq 1 ]; then
# Current binding corpus: independent full-record oracles, twice-run equality and replay.
current_cli="$(realpath "$BIN")"
if python3 tests/fixtures/bindings/current/check.py --root "$PWD" --cli "$current_cli" \
    --output "$tmp/binding-current" >"$tmp/binding-current-summary"; then
  while IFS= read -r case_id; do
    digest "binding current $case_id" "$tmp/binding-current/${case_id/\//.}/a.record.json"
  done < <(python3 -c 'import json,sys; [print(c["id"]) for c in json.load(open(sys.argv[1]))["cases"]]' "$tmp/binding-current-summary")
else
  echo "BINDING CURRENT CONFORMANCE FAILED" >&2
  fail=1
fi

# Admission of every valid wire fixture.
for f in tests/fixtures/wire/valid/*.json; do
  run_twice "admit $f" "$BIN" admit "$f"
  rc=0; "$BIN" admit "$f" >/dev/null || rc=$?
  if [ "$rc" -ne 0 ]; then echo "ADMISSION FAILED: $f" >&2; fail=1; fi
done

# Evaluation and replay of every request fixture (US2).
if [ -f tests/fixtures/requests/expectations.json ]; then
  while IFS=' ' read -r name wire; do
    w="tests/fixtures/wire/valid/$wire.json"
    r="tests/fixtures/requests/$name.json"
    run_twice "eval $name" "$BIN" eval "$w" "$r"
    "$BIN" eval "$w" "$r" >"$tmp/record.json" 2>/dev/null || true
    rc=0; "$BIN" replay "$w" "$tmp/record.json" >/dev/null 2>&1 || rc=$?
    if [ "$rc" -ne 0 ]; then echo "REPLAY MISMATCH: $name" >&2; fail=1; fi
  done < <(python3 -c 'import json,sys; [print(k, v["wire"]) for k, v in sorted(json.load(open(sys.argv[1])).items())]' tests/fixtures/requests/expectations.json)
fi

# Evaluation and replay of the feature 002, 003, 004, 006 and 007 requests (constraints,
# fixed-scale values, exact ratios, evaluation facts, query facts).
for pair in "002:constraints" "003:fixed_scale" "004:exact_closure" "006:accounts" "007:orders"; do
  dir="tests/fixtures/requests/${pair%%:*}"
  w="tests/fixtures/wire/valid/${pair##*:}.json"
  for r in "$dir"/*.json; do
    case "$r" in */expectations.json) continue ;; esac
    run_twice "eval $r" "$BIN" eval "$w" "$r"
    "$BIN" eval "$w" "$r" >"$tmp/record.json" 2>/dev/null || true
    rc=0; "$BIN" replay "$w" "$tmp/record.json" >/dev/null 2>&1 || rc=$?
    if [ "$rc" -ne 0 ]; then echo "REPLAY MISMATCH: $r" >&2; fail=1; fi
  done
done

# Verification attestations (feature 002): every verify fixture and every valid wire file,
# without a cache so the solver runs both times.
# Persistence (feature 005): a fixed store history, its records and replay reports (SC-005).
cargo run -q -p behavior-store --example history >"$tmp/history_a" 2>/dev/null || fail=1
cargo run -q -p behavior-store --example history >"$tmp/history_b" 2>/dev/null || fail=1
digest "store example history" "$tmp/history_a"
if ! cmp -s "$tmp/history_a" "$tmp/history_b" || [ ! -s "$tmp/history_a" ]; then
  echo "NOT DETERMINISTIC: store history" >&2
  fail=1
fi
if [ "$(tail -n 2 "$tmp/history_a" | grep -c '"ok":true')" -ne 2 ]; then
  echo "STORE REPLAY FAILED" >&2
  fail=1
fi
# Entity lifecycle (feature 006): a fixed history with creations, removals and reference changes,
# and its data, behavior and reference replay reports.
cargo run -q -p behavior-store --example lifecycle_history >"$tmp/lifecycle_a" 2>/dev/null || fail=1
cargo run -q -p behavior-store --example lifecycle_history >"$tmp/lifecycle_b" 2>/dev/null || fail=1
digest "store example lifecycle" "$tmp/lifecycle_a"
if ! cmp -s "$tmp/lifecycle_a" "$tmp/lifecycle_b" || [ ! -s "$tmp/lifecycle_a" ]; then
  echo "NOT DETERMINISTIC: lifecycle history" >&2
  fail=1
fi
if [ "$(tail -n 3 "$tmp/lifecycle_a" | grep -c '"ok":true')" -ne 3 ]; then
  echo "LIFECYCLE REPLAY FAILED" >&2
  fail=1
fi
# Relational queries (feature 007): a fixed history whose decisions depend on queries, and its
# data and behavior replay reports.
cargo run -q -p behavior-store --example query_history >"$tmp/query_a" 2>/dev/null || fail=1
cargo run -q -p behavior-store --example query_history >"$tmp/query_b" 2>/dev/null || fail=1
digest "store example query" "$tmp/query_a"
if ! cmp -s "$tmp/query_a" "$tmp/query_b" || [ ! -s "$tmp/query_a" ]; then
  echo "NOT DETERMINISTIC: query history" >&2
  fail=1
fi
if [ "$(tail -n 2 "$tmp/query_a" | grep -c '"ok":true')" -ne 2 ]; then
  echo "QUERY REPLAY FAILED" >&2
  fail=1
fi

# Schema evolution (feature 009): a fixed history crossing two migrations, its records and its
# data and behavior replay reports; and admission and plain application of every migration.
cargo run -q -p behavior-store --example migration_history >"$tmp/migration_a" 2>/dev/null || fail=1
cargo run -q -p behavior-store --example migration_history >"$tmp/migration_b" 2>/dev/null || fail=1
digest "store example migration" "$tmp/migration_a"
if ! cmp -s "$tmp/migration_a" "$tmp/migration_b" || [ ! -s "$tmp/migration_a" ]; then
  echo "NOT DETERMINISTIC: migration history" >&2
  fail=1
fi
if [ "$(tail -n 2 "$tmp/migration_a" | grep -c '"ok":true')" -ne 2 ]; then
  echo "MIGRATION REPLAY FAILED" >&2
  fail=1
fi
for m in tests/fixtures/migration/valid/*.json; do
  case "$m" in *.expected.json) continue ;; esac
  e="${m%.json}.expected.json"
  src="tests/fixtures/migration/modules/$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["source"])' "$e").json"
  dst="tests/fixtures/migration/modules/$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["target"])' "$e").json"
  run_twice "migration admit $m" "$BIN" migration admit "$src" "$dst" "$m"
  rc=0; "$BIN" migration admit "$src" "$dst" "$m" >/dev/null || rc=$?
  if [ "$rc" -ne 0 ]; then echo "MIGRATION ADMISSION FAILED: $m" >&2; fail=1; fi
done

# First-class reads (feature 010): every golden read request, read twice and replayed.
for r in tests/fixtures/reads/requests/*.json; do
  w=tests/fixtures/reads/modules/lab.json
  run_twice "read $r" "$BIN" read "$w" "$r"
  "$BIN" read "$w" "$r" >"$tmp/read.json" 2>/dev/null || true
  if ! cmp -s "$tmp/read.json" "tests/fixtures/reads/records/$(basename "${r%.json}").expected.json"; then
    echo "READ RECORD DIFFERS FROM GOLDEN: $r" >&2; fail=1
  fi
  rc=0; "$BIN" read-replay "$w" "$tmp/read.json" >/dev/null 2>&1 || rc=$?
  if [ "$rc" -ne 0 ]; then echo "READ REPLAY MISMATCH: $r" >&2; fail=1; fi
done

# Unified invocation: compare independent semantic outcomes of fresh Current
# actions and reproduce immutable archives separately.
if ! scripts/check-invocation-determinism.sh; then fail=1; fi
if ! scripts/check-command-determinism.sh; then fail=1; fi
if ! python3 scripts/check-resulting-state-determinism.py; then fail=1; fi
if ! scripts/check-replay-determinism.sh; then fail=1; fi
if ! scripts/check-replay-evidence-determinism.sh; then fail=1; fi

if command -v "${BEHAVIOR_Z3:-z3}" >/dev/null 2>&1; then
  for m in tests/fixtures/migration/valid/*.json; do
    case "$m" in *.expected.json) continue ;; esac
    e="${m%.json}.expected.json"
    src="tests/fixtures/migration/modules/$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["source"])' "$e").json"
    dst="tests/fixtures/migration/modules/$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["target"])' "$e").json"
    run_twice "migration verify $m" "$BIN" migration verify "$src" "$dst" "$m"
  done
  for f in tests/fixtures/verify/*.json tests/fixtures/wire/valid/*.json; do
    case "$f" in *.expected.json) continue ;; esac
    run_twice "verify $f" "$BIN" verify "$f"
  done

  # A governance decision: a forced-inconclusive finding (resource limit 1, not a hard model)
  # waived with the test key.
  g=tests/fixtures/governance
  w=tests/fixtures/verify/purchase_remaining.json
  "$BIN" verify "$w" --profile "$g/forced_inconclusive_profile.json" >"$tmp/att.json" || true
  # Trusted host supplies the actual complete parent, including empty types.
  # Bound entities alone are not a complete-world validity certificate.
  python3 - "$w" "$g/approve_request.json" "$tmp/approve-current.json" <<'PYREQ'
import json,sys
module=json.load(open(sys.argv[1])); request=json.load(open(sys.argv[2]))
params={p['name']:p['type']['name'] for action in module['actions'] if action['name']==request['action'] for p in action['params'] if p['role']=='state'}
rows={entity['name']:{} for entity in module['entities']}
for name,row in request['state'].items():
    rows[params[name]][row['id']]=row
request['facts']={'universe':[{'entity':name,'members':list(members.values())} for name,members in sorted(rows.items())]}
json.dump(request,open(sys.argv[3],'w'))
PYREQ
  "$BIN" eval "$w" "$tmp/approve-current.json" >"$tmp/rec.json" || true
  python3 - "$tmp" <<'PY'
import json, sys
tmp = sys.argv[1]
a = json.load(open(f"{tmp}/att.json"))
f = a["findings"][0]
json.dump({"behavior_version": a["behavior_version"], "finding_hash": f["hash"],
           "profile_hash": a["profile"]["hash"], "verifier_version": a["verifier_version"],
           "rationale": "determinism check"}, open(f"{tmp}/waiver.json", "w"))
open(f"{tmp}/seed", "w").write(json.load(open("tests/fixtures/governance/keys.json"))["A"]["seed"])
PY
  "$BIN" sign-waiver "$tmp/waiver.json" --seed "$tmp/seed" >"$tmp/signed.json"
  run_twice "authorize (waived inconclusive)" "$BIN" authorize "$w" "$tmp/rec.json" \
    --policy "$g/verified_or_waived.json" --attestation "$tmp/att.json" \
    --waiver "$tmp/waiver.json" --signature "$tmp/signed.json" --now 2026-09-25T12:00:00Z
  rc=0; "$BIN" authorize "$w" "$tmp/rec.json" --policy "$g/verified_or_waived.json" \
    --attestation "$tmp/att.json" --waiver "$tmp/waiver.json" --signature "$tmp/signed.json" \
    --now 2026-09-25T12:00:00Z >/dev/null || rc=$?
  if [ "$rc" -ne 0 ]; then echo "AUTHORIZE: expected allow for the waived case" >&2; fail=1; fi
else
  echo "determinism-check: z3 not found; skipping verification checks" >&2
fi

fi

if [ "$fail" -ne 0 ]; then
  echo "determinism-check: FAILED" >&2
  exit 1
fi
echo "determinism-check: OK"
